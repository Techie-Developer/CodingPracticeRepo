package com.codingPractice;

import java.util.HashMap;

public class Find_Element_Pairs_Equal_To_Given_Number_In_Array {
	
	static int arr[] = new int[]{3, 6, 8, -8, 10, 8 } ; 
	
	// Returns number of pairs in arr[0..n-1] with sum equal 
	// to 'sum' 
	static int getPairsCount(int n, int sum) 
	{ 
		HashMap<Integer, Integer> hm = new HashMap<>(); 

		// Store counts of all elements in map hm 
		for (int i=0; i<n; i++){ 
			
			// initializing value to 0, if key not found 
			if(!hm.containsKey(arr[i])) 
				hm.put(arr[i],0); 
				
			hm.put(arr[i], hm.get(arr[i])+1); 
		} 
		int twice_count = 0; 

		// iterate through each element and increment the 
		// count (Notice that every pair is counted twice) 
		for (Integer x:hm.keySet()) 
		{ 
			if(hm.get(sum-x) != null) 
				twice_count += hm.get(sum-x); 

			// if (arr[i], arr[i]) pair satisfies the condition, 
			// then we need to ensure that the count is 
			// decreased by one such that the (arr[i], arr[i]) 
			// pair is not considered 
			if (sum-x == x) 
				twice_count--; 
		} 

		// return the half of twice_count 
		return twice_count/2; 
	} 

	// Driver method to test the above function 
	public static void main(String[] args) { 
		
		int sum = 16; 
		System.out.println("Count of pairs are : " + 
							getPairsCount(arr.length,sum)); 
		
	} 
	

}
