package com.codingPractice;

public class Find_Smallest_Pair_Sum_In_Array{ 
	
	static int smallest_pair_addition(int[] a, int n) 
	{ 
		int min = Integer.MAX_VALUE, secondMin = Integer.MAX_VALUE;
		
		for (int j = 0; j < n; j++) 
		{ 
			if (a[j] < min) 
			{ 
				secondMin = min; 
				min = a[j]; 
			} 

			else if ((a[j] < secondMin) && a[j] != min) 
				secondMin = a[j]; 
		} 

		return (secondMin + min); 
	} 

	public static void main(String[] args) 
	{ 
		int[] arr = { 1, 2, 3 }; 
		int n = arr.length; 

		System.out.println("Smallest Pair Sum in Given Array is : " +smallest_pair_addition(arr, n)); 
	} 
}