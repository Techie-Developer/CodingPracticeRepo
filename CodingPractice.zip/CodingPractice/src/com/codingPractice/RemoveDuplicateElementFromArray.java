package com.codingPractice;

import java.util.HashMap;

public class RemoveDuplicateElementFromArray {
 
	 static void removeDups(int[] arr, int n)  
	    { 
	        HashMap<Integer,  
	                Boolean> mp = new HashMap<>(); 
	  
	        for (int i = 0; i < n; ++i) 
	        { 
	            if (mp.get(arr[i]) == null) 
	                System.out.print(arr[i] + " "); 
	  
	            mp.put(arr[i], true); 
	        } 
	    } 
	  
	    public static void main(String[] args) 
	    { 
	        int[] arr = { 1, 2, 5, 5, 6, 6, 7, 2 }; 
	        int n = arr.length; 
	        removeDups(arr, n); 
	    } 
	    
}