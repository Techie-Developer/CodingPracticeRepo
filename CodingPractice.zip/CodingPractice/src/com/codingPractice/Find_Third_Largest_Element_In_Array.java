package com.codingPractice;

public class Find_Third_Largest_Element_In_Array {

    public static int getThirdLargest(int[] a, int n){  
    	int temp;  
    	for (int i = 0; i < n; i++)   
    	        {  
    	            for (int j = i + 1; j < n; j++)   
    	            {  
    	                if (a[i] > a[j])   
    	                {  
    	                    temp = a[i];  
    	                    a[i] = a[j];  
    	                    a[j] = temp;  
    	                }  
    	            }  
    	        }  
    	       return a[n-3];  
    	}
    
    	public static void main(String args[]){  
    	int a[]={6, 8, 1, 9, 2, 1, 10};  
    	System.out.println("Third Largest Element of given Array : "+getThirdLargest(a,7));
    	}

}
