package com.codingPractice;

import java.util.HashSet;

public class FindUniqueElementsSumInArray {

    static int findSum(int arr[], int n) 
    { 
        int sum = 0; 
  
        HashSet<Integer> hashSet = new HashSet<Integer>(); 
        
        for (int i = 0; i < n; i++) 
        { 
            if (!hashSet.contains(arr[i])) 
            { 
                sum += arr[i]; 
                hashSet.add(arr[i]); 
            } 
        } 
        return sum; 
    } 
  
    public static void main(String[] args)  
    { 
        int arr[] = {1, 6, 4, 3, 2, 2, 3, 8, 1}; 
        int n = arr.length; 
        System.out.println(findSum(arr, n)); 
    }
    
}
