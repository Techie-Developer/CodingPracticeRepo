package com.codingPractice;

public class DifferenceBNTwoElementsInArray{
	
	    static void findGap(int [] a)
	    {
	        if(a==null || a.length==0)
	        {
	            System.out.println("Array is null, no solution found");
	        }
	        
	        int max_so_far = a[0];
	        int min_so_far = a[0];
	        int max_diff = 0;
	        
	        for (int i = 1; i <a.length ; i++)
	        {
	            if(a[i]>max_so_far)
	                max_so_far = a[i];
	            
	            if(a[i]<min_so_far)
	                min_so_far = a[i];
	        }
	        
	        max_diff = max_so_far - min_so_far;
	        System.out.println("Maximum Difference between two elements in this Array is : " +  max_diff);
	    }

	    public static void main(String[] args) {
	        int [] arr = {2, 5, 1, 7, 3, 9, 5};
	        findGap(arr);
	    }

}
