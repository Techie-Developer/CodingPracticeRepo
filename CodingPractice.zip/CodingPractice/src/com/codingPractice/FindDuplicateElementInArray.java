package com.codingPractice;

public class FindDuplicateElementInArray {
	
	public static void main(String[] args) 
    {
        int[] arr = {1, 2, 5, 5, 6, 6, 7, 2};
 
        for (int m = 0; m < arr.length-1; m++)
        {
            for (int n = m+1; n < arr.length; n++)
            {
                if ((arr[m] == arr[n]) && (m != n))
                {
                    System.out.print(arr[n] +" ");
                }
            }
        }
    }    

}
