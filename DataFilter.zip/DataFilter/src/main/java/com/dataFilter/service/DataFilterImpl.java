package com.dataFilter.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.dataFilter.model.ProductInfo;


@Service
public class DataFilterImpl implements IDataFilter {

	@Override
	public List<ProductInfo> applyFilterOnCvsData(List<ProductInfo> productInfoList) {
		
		productInfoList.stream()
	    .filter(p->p.getProductPrice()>6000)
	    .collect(Collectors.toList());
		
		return productInfoList;
	}

}
