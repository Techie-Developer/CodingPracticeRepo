package com.dataFilter.service;

import java.util.List;

import com.dataFilter.model.ProductInfo;

public interface IDataFilter {

	public List<ProductInfo> applyFilterOnCvsData(List<ProductInfo> productInfoList);
}
