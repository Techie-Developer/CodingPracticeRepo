package com.dataFilter.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.dataFilter.model.ProductInfo;
import com.dataFilter.service.IDataFilter;



@Component
public class CSVFileReaderUtility {
	
	private IDataFilter dataFilter;
	
	@Autowired
	public CSVFileReaderUtility(IDataFilter dataFilter) {
		this.dataFilter = dataFilter;
	}


	public List<ProductInfo> readFileData() throws Exception{
		
		FileReader fr = new FileReader(new File("Products.txt"));
		BufferedReader br = new BufferedReader(fr);
		String lineData = br.readLine();
		List<ProductInfo> pList=new ArrayList<ProductInfo>();
		
		while(lineData !=null) {
			String split[] = lineData.split(",");
			
			String pid=split[0];
			String pname=split[1];
			String price=split[2];
			
			ProductInfo pf=new ProductInfo();
			pf.setProductId(Integer.parseInt(pid));
			pf.setProudctName(pname);
			pf.setProductPrice(Double.parseDouble(price));
			
			pList.add(pf);
			lineData=br.readLine();
		}
		
		br.close();
		
		return dataFilter.applyFilterOnCvsData(pList);
	}
}
