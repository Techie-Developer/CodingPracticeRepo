package com.dataFilter;

import java.util.List;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import com.dataFilter.model.ProductInfo;
import com.dataFilter.utility.CSVFileReaderUtility;



@SpringBootApplication
public class DataFilterApplication {

	public static void main(String[] args) throws Exception {
		ConfigurableApplicationContext Ctxt=SpringApplication.run(DataFilterApplication.class, args);
		CSVFileReaderUtility cvsReader = Ctxt.getBean(CSVFileReaderUtility.class);
		List<ProductInfo> productList = cvsReader.readFileData();
		productList.forEach(System.out::println);
	}
}
